// (function ($, Drupal, once) {
//   Drupal.behaviors.myModuleBehavior = {
//     attach: function (context, settings) {
//         console.log('arijit'); 
//       $('.single-item').slick({
//           infinite: true,
//           slidesToShow: 2,
//           slidesToScroll: 1,
//           arrows: true
//         });  
//         $(".single-item"). css("background-color","blue");
//     }
//   };
// })(jQuery, Drupal, once);

